# Pi + Arduino Retro-TV Enclosure v13 — Slide Cover Behind the Screen Hole

## What changed this round
The slide-in mechanism now lives directly **behind the screen opening**,
not at the far back of the (now very deep, 215mm) box. It's sized to fit
the screen hole closely:

- The sliding cover is **1cm (10mm) bigger than the screen hole on every
  side**: 251 x 150mm (231+20 x 130+20).
- Its rails are attached to the inside of the front wall, right around the
  screen hole, with a 10mm gap behind the front wall for your laptop
  screen's thickness — same as before, just relocated to where the screen
  actually is instead of the box's rear.
- The cover drops in from the top of the box (before the top panel goes
  on) and slides down until it rests directly behind the screen hole.

## Files
- `enclosure_v5.scad` — source model, open in OpenSCAD (free, openscad.org) to tweak anything.
- `side_frame.stl` — the fused front+back+left+right wall piece: screen opening, control cutouts, and the repositioned slide rails behind the screen.
- `bottom_panel.stl` — floor panel, has the Pi + Arduino standoffs built in.
- `top_panel.stl` — lid.
- `laptop_backplate.stl` — the small sliding cover (251 x 150mm), no longer full-width.
- `preview_v13_assembly.png` / `preview_v13_exploded.png` — the full build.

## Dimensions
- Width (X): 305mm, Height (Z): 215mm.
- Depth (Y): 215mm — fat/chunky retro-TV body (the electronics bay behind
  the screen mechanism).
- Screen opening: 231 x 130mm, 15mm down from the top.
- Sliding cover: 251 x 150mm (screen hole + 1cm margin all around).
- Control cluster: joystick 20mm + 4x M2 mounts, potentiometer 7mm, button 24mm.

## How the slide-in cover works
1. Two short rails are built onto the inside of the front wall, one on
   each side of the (screen hole + 1cm) rectangle, reaching back 10mm
   (the laptop screen gap) then forming a thin channel.
2. With the top panel off, drop the cover in from the top of the box and
   slide it down the rails until it settles directly behind the screen
   hole.
3. Screw the top panel on last to cap the channel.
4. In use: your laptop's screen edge sits in the 10mm gap between the
   front wall (around the screen hole) and the cover, clamped snugly since
   the cover is sized just 1cm larger than the hole itself.

## How the rest goes together
- The frame's 4 corner posts (15 x 15mm) have pilot holes at top and
  bottom for the top/bottom panels (self-tapping M3, 2.6mm pilot holes,
  3.4mm clearance holes in the panels).
- The bottom panel carries the Pi 4 / Arduino Uno standoffs.
- Mount the joystick module behind the front wall with 4 self-tapping M2
  screws; the potentiometer and button push/screw through their holes
  from the front.

## Before you print
- **Measure your laptop screen's actual thickness** — adjust
  `laptop_screen_t` if it's not ~10mm.
- **Rail slot clearance** (`rail_clearance = 0.6mm`) is a starting guess
  for 3D-printed slide-fits — test print a short section first.
- **Measure your real laptop screen's visible area** and adjust `screen_w`
  / `screen_h` / `screen_top_margin` to match — the cover and rails resize
  automatically since they're derived from the screen dimensions.
- At 305 x 215mm, `side_frame.stl` exceeds most standard 3D printer beds
  (~220-250mm) — split it for printing, or laser-cut from 3mm
  acrylic/plywood, which handles this size in one piece.

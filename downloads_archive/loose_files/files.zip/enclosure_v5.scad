// =====================================================================
//  Pi + Arduino Retro-TV Enclosure — ONE-PIECE SIDE FRAME
//  Front + back + left + right walls are now a single fused frame
//  ("side_frame"), with small square corner posts built in (holding the
//  screw holes for the top/bottom panels and the backplate). Only the
//  top panel and bottom panel remain separate/removable.
//
//  Orientation: the frame now stands upright so its front/back faces
//  are the SAME HEIGHT as the laptop backplate (215mm) - like a real
//  retro TV cabinet, wide and tall with a shallow front-to-back depth.
// =====================================================================
//  HOW TO USE
//  - Open in OpenSCAD (free, openscad.org)
//  - Set PART to render/export one piece at a time:
//      "assembly"   -> everything shown together, for viewing only
//      "side_frame" -> the ONE fused front+back+left+right wall piece
//      "bottom"     -> bottom panel (has the Pi + Arduino standoffs)
//      "top"        -> top panel
//      "backplate"  -> the laptop-screen backplate
//  - File > Export > Export as STL exports whatever PART is showing
// =====================================================================

PART = "assembly";

// ---------------------- CORE DIMENSIONS ----------------------
box_w      = 305;   // box width  (X) = backplate width
box_h      = 215;   // box HEIGHT (Z) = backplate height  <- front/back/left/right walls are this tall
box_d      = 215;   // box depth  (Y) - now matching the height, for a fat/chunky retro-TV body
t          = 3;     // wall thickness
corner_sq  = 15;    // small square reinforcement post at each of the 4 corners (mm)

// ---------------------- SCREW HOLES ----------------------
pilot_d      = 2.6;   // pilot hole drilled INTO corner posts, for self-tapping M3
panel_hole_d = 3.4;   // clearance hole THROUGH panels/backplate, for M3
hole_depth   = 7;     // how deep a pilot hole goes into a corner post
back_hole_f  = [0.35, 0.65];  // fractions of box_h - backplate attachment hole heights

// ---------------------- STANDOFFS (Pi / Arduino) ----------------------
standoff_h   = 6;
standoff_od  = 6.5;
pi_pilot_d   = 2.0;    // self-tapping M2.5
uno_pilot_d  = 2.5;    // self-tapping M3

pi_hole_spacing_x = 58;    // Raspberry Pi 4B / 3B+ mounting rectangle
pi_hole_spacing_y = 49;
uno_holes = [               // Arduino Uno R3 standard 4-hole pattern
    [15.24, 2.54],
    [15.24, 50.80],
    [66.04, 17.78],
    [66.04, 45.72]
];
// Both boards laid out side by side along the width (X), since depth (Y)
// is now only 70mm - tight, so double-check against your real boards.
pi_origin  = [20, 10];
uno_origin = [115, 8];

// ---------------------- RETRO-TV SCREEN OPENING ----------------------
// A rectangular cutout in the front wall so the laptop screen shows
// through, like an old TV screen. Adjust to your laptop's actual visible
// screen area.
screen_top_margin = 15;    // gap from the top edge of the frame
screen_w = 231;             // ~16:9 given the height below
screen_h = 130;
screen_x0 = (box_w - screen_w)/2;
screen_z0 = box_h - screen_top_margin - screen_h;

// ---------------------- LAPTOP SLIDE-IN COVER (behind the screen hole) ----------------------
// Slides into rail channels positioned directly behind the screen opening
// (not the far back of the box), sized to fit the screen hole with a 1cm
// margin all around. The laptop's screen (lid) is ~10mm thick, so that's
// the air gap left between the front wall and the sliding cover - the
// lid's edge sits in that gap, clamped between the screen bezel and the
// cover.
laptop_screen_t = 10;    // laptop screen (lid) thickness
rail_wall_t     = 2;     // thickness of each thin rail wall
rail_clearance  = 0.6;   // extra slack so the cover slides freely
rail_w          = 10;    // rail width in X
slide_margin    = 10;    // 1cm bigger than the screen hole, on every side
// the sliding cover's footprint: screen hole + 1cm margin on all sides
backplate_w = screen_w + 2*slide_margin;
backplate_h = screen_h + 2*slide_margin;
backplate_t = 3;
backplate_x0 = screen_x0 - slide_margin;   // where the cover's rest position starts (X)
backplate_z0 = screen_z0 - slide_margin;   // where the cover's rest position starts (Z)
rail_slot   = backplate_t + rail_clearance;   // gap the cover rides in


// ---------------------- RETRO-TV CONTROL CLUSTER ----------------------
// Positioned UNDER the screen opening, like an old TV's control panel.
// Sized for real hardware:
//  - Joystick: standard 2-axis breadboard joystick module (5-pin, KY-023
//    style) - 24mm clearance hole for the stick's full range of motion,
//    plus 4 small M2 pilot holes to screw the module's PCB on from behind
//    (common hole spacing on these modules is ~19.5 x 19.5mm - measure
//    your exact module and adjust `joystick_mount_spacing` if different).
//  - Potentiometer: standard 10K rotary pot with a 6mm knurled/D shaft -
//    7mm hole for the bushing to poke through.
//  - Button: 24mm mounting hole, the standard panel cutout for an arcade
//    -style button with a 30mm (3cm) cap.
joystick_hole_d = 20;
joystick_mount_spacing = 19.5;   // adjust to your exact module
joystick_mount_pilot_d = 2.0;    // self-tapping M2
knob_hole_d     = 7;    // 10K potentiometer bushing/shaft clearance
button_hole_d   = 24;   // panel hole for a 30mm-cap arcade button
ctrl_gap        = 25;
ctrl_pitch      = 40;   // fixed center-to-center spacing (independent of hole size now)
ctrl_center_x   = box_w/2;
ctrl_center_z   = 30;   // fixed height from the bottom, well below the screen opening
ctrl_positions = [
    [ctrl_center_x - ctrl_pitch, ctrl_center_z, joystick_hole_d],
    [ctrl_center_x,              ctrl_center_z, knob_hole_d],
    [ctrl_center_x + ctrl_pitch, ctrl_center_z, button_hole_d]
];
joystick_center = ctrl_positions[0];   // used to place the 4 mounting holes

// =====================================================================
//  CORNERS  — posts = [signX, signY]  (-1 = near 0, +1 = near box_w/box_d)
// =====================================================================
corners = [[-1,-1], [1,-1], [-1,1], [1,1]];

function corner_x0(signX) = (signX < 0) ? 0 : box_w - corner_sq;
function corner_y0(signY) = (signY < 0) ? 0 : box_d - corner_sq;

// =====================================================================
//  ONE-PIECE SIDE FRAME (front + back + left + right, fused)
// =====================================================================
module side_frame() {
    color("lightgreen")
    union() {
        difference() {
            union() {
                // hollow perimeter tube
                difference() {
                    cube([box_w, box_d, box_h]);
                    translate([t, t, -1])
                        cube([box_w-2*t, box_d-2*t, box_h+2]);
                }
                // 4 solid corner posts, fused into the tube
                for (c = corners)
                    translate([corner_x0(c[0]), corner_y0(c[1]), 0])
                        cube([corner_sq, corner_sq, box_h]);
            }

            // top + bottom pilot holes at every corner post
            for (c = corners) {
                cx = corner_x0(c[0]) + corner_sq/2;
                cy = corner_y0(c[1]) + corner_sq/2;
                translate([cx, cy, box_h - hole_depth])
                    cylinder(d=pilot_d, h=hole_depth+0.5, $fn=16);
                translate([cx, cy, -0.5])
                    cylinder(d=pilot_d, h=hole_depth+0.5, $fn=16);
            }

            // retro-TV control cluster, through the front wall (y: 0..t)
            for (c = ctrl_positions)
                translate([c[0], -0.5, c[1]])
                    rotate([-90,0,0])
                        cylinder(d=c[2], h=t+1, $fn=48);

            // joystick module mounting screws (4x, around the joystick hole)
            for (dx = [-1,1]) for (dz = [-1,1])
                translate([joystick_center[0] + dx*joystick_mount_spacing/2,
                           -0.5,
                           joystick_center[1] + dz*joystick_mount_spacing/2])
                    rotate([-90,0,0])
                        cylinder(d=joystick_mount_pilot_d, h=t+1, $fn=12);

            // screen opening, through the front wall - laptop screen shows through
            translate([screen_x0, -0.5, screen_z0])
                cube([screen_w, t+1, screen_h]);
        }

        // slide-in rails for the backplate, on the 2 back corners - built
        // out from the back face by the laptop screen thickness, then a
        // thin channel the backplate rides in
        // slide-in rails for the laptop cover, positioned directly BEHIND
        // the screen hole (attached to the inside of the front wall) -
        // not at the far back of the box. Two vertical rails, one at each
        // side of the (screen hole + 1cm margin) rectangle, spanning from
        // the cover's rest height up to the top of the box so it can be
        // dropped in from the top opening and slid down into place.
        rail_channel_z0 = backplate_z0;          // where the cover rests, aligned with the screen hole
        rail_channel_h  = box_h - rail_channel_z0;
        for (rx = [backplate_x0, backplate_x0 + backplate_w - rail_w]) {
            // connecting arm across the laptop-screen air gap
            translate([rx, t, rail_channel_z0])
                cube([rail_w, laptop_screen_t, rail_channel_h]);
            // inner channel wall
            translate([rx, t + laptop_screen_t, rail_channel_z0])
                cube([rail_w, rail_wall_t, rail_channel_h]);
            // outer channel wall (lip) - traps the cover in the slot
            translate([rx, t + laptop_screen_t + rail_wall_t + rail_slot, rail_channel_z0])
                cube([rail_w, rail_wall_t, rail_channel_h]);
        }
    }
}

// =====================================================================
//  TOP / BOTTOM PANELS
// =====================================================================
module top_panel() {
    color("plum")
    difference() {
        cube([box_w, box_d, t]);
        for (c = corners) {
            cx = corner_x0(c[0]) + corner_sq/2;
            cy = corner_y0(c[1]) + corner_sq/2;
            translate([cx, cy, -0.5])
                cylinder(d=panel_hole_d, h=t+1, $fn=16);
        }
    }
}

module bottom_panel() {
    color("plum")
    union() {
        difference() {
            cube([box_w, box_d, t]);
            for (c = corners) {
                cx = corner_x0(c[0]) + corner_sq/2;
                cy = corner_y0(c[1]) + corner_sq/2;
                translate([cx, cy, -0.5])
                    cylinder(d=panel_hole_d, h=t+1, $fn=16);
            }
        }
        pi_standoffs();
        uno_standoffs();
    }
}

module pi_standoffs() {
    translate([pi_origin[0], pi_origin[1], t])
        for (p = [[0,0],[0,pi_hole_spacing_y],[pi_hole_spacing_x,0],[pi_hole_spacing_x,pi_hole_spacing_y]])
            translate([p[0], p[1], 0])
                difference() {
                    cylinder(d=standoff_od, h=standoff_h, $fn=24);
                    translate([0,0,-0.5]) cylinder(d=pi_pilot_d, h=standoff_h+1, $fn=16);
                }
}

module uno_standoffs() {
    translate([uno_origin[0], uno_origin[1], t])
        for (p = uno_holes)
            translate([p[0], p[1], 0])
                difference() {
                    cylinder(d=standoff_od, h=standoff_h, $fn=24);
                    translate([0,0,-0.5]) cylinder(d=uno_pilot_d, h=standoff_h+1, $fn=16);
                }
}

// ---------------------- LAPTOP BACKPLATE (slides into the rails) ----------------------
module backplate() {
    color("gray")
    cube([backplate_w, backplate_t, backplate_h]);
}

// =====================================================================
//  ASSEMBLY
// =====================================================================
EXPLODE = 0;

module assembly() {
    side_frame();
    translate([0, 0, -EXPLODE])         bottom_panel();
    translate([0, 0, box_h-t+EXPLODE])  top_panel();
    // cover shown slid down into its rest position behind the screen hole
    // (plus EXPLODE offset outward, for clarity)
    translate([backplate_x0, t + laptop_screen_t + rail_wall_t + EXPLODE, backplate_z0])
        backplate();
}

// =====================================================================
//  RENDER SELECTOR
// =====================================================================
if (PART == "side_frame") side_frame();
else if (PART == "bottom") bottom_panel();
else if (PART == "top") top_panel();
else if (PART == "backplate") backplate();
else assembly();

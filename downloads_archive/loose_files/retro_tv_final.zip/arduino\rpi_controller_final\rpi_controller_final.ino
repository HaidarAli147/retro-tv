// =====================================================================
//  Retro-TV controller  -  FINAL
//
//  Joystick  -> UP / DOWN / LEFT / RIGHT, press = ENTER
//  Knob      -> VOL_UP / VOL_DOWN
//
//  Prints plain text lines over serial at 9600 baud. rpi_bridge.py on the
//  Raspberry Pi turns them into key presses. No IR receiver and no
//  external libraries are used.
//
//  The power button is NOT on the Arduino. It wires to the Pi's GPIO3
//  (physical pin 5) and GND, so it can also switch the Pi back on while
//  it is off - see power_button.py. Never wire that button to both
//  boards: the Arduino pulls its pins to 5V and the Pi's GPIO is 3.3V.
//
//  WIRING
//    Joystick GND -> GND        Joystick +5V -> 5V
//    Joystick VRx -> A0         Joystick VRy -> A1
//    Joystick SW  -> D2
//    Knob outer leg -> 5V   middle (wiper) -> A2   other outer leg -> GND
//  The Uno has one 5V pin, so join the joystick and knob 5V leads into it.
//  It has three GND pins, so give each part its own.
// =====================================================================

const int JOYSTICK_X_PIN  = A0;
const int JOYSTICK_Y_PIN  = A1;
const int JOYSTICK_SW_PIN = 2;    // joystick press -> ENTER
const int VOLUME_PIN      = A2;

// Joystick. Raise JOYSTICK_DEADZONE if a centred stick drifts and sends
// stray directions; lower it if the stick feels unresponsive.
const int JOYSTICK_CENTER   = 512;
const int JOYSTICK_DEADZONE = 200;
const unsigned long NAV_REPEAT_DELAY = 150;  // ms between repeats while held
const unsigned long ENTER_DEBOUNCE   = 200;  // ms

// Volume knob. Averaging plus a commit threshold is what stops the
// phantom VOL_UP/VOL_DOWN chatter a raw analogRead produces.
const int VOL_SAMPLES        = 8;    // readings averaged per sample
const int VOL_TRIGGER_DELTA  = 40;   // averaged value must move this far
const unsigned long VOL_INTERVAL = 120;  // ms between samples

int lastVolCommitted = -1;
unsigned long lastVolTime   = 0;
unsigned long lastNavTime   = 0;
unsigned long lastEnterTime = 0;
bool enterWasPressed = false;

int readVolumeAveraged() {
  long sum = 0;
  for (int i = 0; i < VOL_SAMPLES; i++) {
    sum += analogRead(VOLUME_PIN);
    delayMicroseconds(200);
  }
  return sum / VOL_SAMPLES;
}

void setup() {
  Serial.begin(9600);
  pinMode(JOYSTICK_SW_PIN, INPUT_PULLUP);
  lastVolCommitted = readVolumeAveraged();
}

void loop() {
  unsigned long now = millis();

  // --- Joystick direction ---
  if (now - lastNavTime > NAV_REPEAT_DELAY) {
    int xVal = analogRead(JOYSTICK_X_PIN);
    int yVal = analogRead(JOYSTICK_Y_PIN);

    if (xVal < JOYSTICK_CENTER - JOYSTICK_DEADZONE) {
      Serial.println("LEFT");  lastNavTime = now;
    } else if (xVal > JOYSTICK_CENTER + JOYSTICK_DEADZONE) {
      Serial.println("RIGHT"); lastNavTime = now;
    } else if (yVal < JOYSTICK_CENTER - JOYSTICK_DEADZONE) {
      Serial.println("UP");    lastNavTime = now;
    } else if (yVal > JOYSTICK_CENTER + JOYSTICK_DEADZONE) {
      Serial.println("DOWN");  lastNavTime = now;
    }
  }

  // --- Joystick press = ENTER (once per press, release required) ---
  bool enterPressed = (digitalRead(JOYSTICK_SW_PIN) == LOW);
  if (enterPressed && !enterWasPressed && (now - lastEnterTime > ENTER_DEBOUNCE)) {
    Serial.println("ENTER");
    lastEnterTime = now;
  }
  enterWasPressed = enterPressed;

  // --- Volume knob ---
  if (now - lastVolTime >= VOL_INTERVAL) {
    lastVolTime = now;
    int avgVol = readVolumeAveraged();
    int delta  = avgVol - lastVolCommitted;
    if (abs(delta) >= VOL_TRIGGER_DELTA) {
      Serial.println(delta > 0 ? "VOL_UP" : "VOL_DOWN");
      lastVolCommitted = avgVol;
    }
  }
}

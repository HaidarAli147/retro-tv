#!/usr/bin/env python3
"""Arduino serial commands -> virtual keyboard events via evdev.

Reads plain text lines from the Arduino (LEFT / RIGHT / UP / DOWN / ENTER /
VOL_UP / VOL_DOWN) and replays them as key press+release events on a virtual
input device, so Kodi or any other app sees ordinary keyboard input.
POWER is handled separately: it shuts the machine down directly rather than
going through the keyboard, so it works no matter what is on screen.

Needs root for /dev/uinput and for the shutdown. The systemd unit runs it
as root; to run it by hand use sudo.
"""
import glob
import logging
import subprocess
import sys
import time

import serial
from evdev import UInput, ecodes as e

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("rpi_bridge")

BAUD_RATE = 9600
CANDIDATE_PORTS = ["/dev/ttyUSB0", "/dev/ttyACM0", "/dev/ttyUSB1", "/dev/ttyACM1"]
RECONNECT_DELAY = 2      # seconds between reconnect attempts
# Tried in order. Distros put shutdown in different places, and a missing
# binary must not take the bridge down with it.
SHUTDOWN_CMDS = [
    ["/sbin/shutdown", "-h", "now"],
    ["/usr/sbin/shutdown", "-h", "now"],
    ["systemctl", "poweroff"],
]

KEY_MAP = {
    "LEFT":     e.KEY_LEFT,
    "RIGHT":    e.KEY_RIGHT,
    "UP":       e.KEY_UP,
    "DOWN":     e.KEY_DOWN,
    "ENTER":    e.KEY_ENTER,
    "VOL_UP":   e.KEY_VOLUMEUP,
    "VOL_DOWN": e.KEY_VOLUMEDOWN,
}


def find_port():
    for path in CANDIDATE_PORTS:
        if glob.glob(path):
            return path
    matches = sorted(glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*"))
    return matches[0] if matches else None


def open_serial():
    while True:
        port = find_port()
        if port:
            try:
                ser = serial.Serial(port, BAUD_RATE, timeout=1)
                log.info("Connected to Arduino on %s", port)
                return ser
            except serial.SerialException as exc:
                log.warning("Failed to open %s: %s", port, exc)
        else:
            log.warning("No Arduino serial device found, retrying...")
        time.sleep(RECONNECT_DELAY)


def main():
    # Advertise a full keyboard's key range, not just the 7 keys we send.
    # A device offering only a handful of keys is not always classified as a
    # keyboard, and then apps like Kodi ignore it.
    all_keys = sorted(set(range(e.KEY_ESC, e.KEY_COMPOSE + 1)) | set(KEY_MAP.values()))
    ui = UInput({e.EV_KEY: all_keys}, name="rpi-arduino-controller")
    # give udev a moment to publish the new device before sending anything
    time.sleep(0.5)
    log.info("Virtual input device created")

    ser = open_serial()
    try:
        while True:
            try:
                line = ser.readline().decode(errors="ignore").strip()
            except (serial.SerialException, OSError) as exc:
                log.warning("Serial error (%s), reconnecting...", exc)
                try:
                    ser.close()
                except Exception:
                    pass
                ser = open_serial()
                continue

            if not line:
                continue

            if line == "POWER":
                log.info("Power button held - shutting down")
                for cmd in SHUTDOWN_CMDS:
                    try:
                        subprocess.run(cmd, check=True)
                        break
                    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
                        log.warning("%s failed: %s", cmd[0], exc)
                else:
                    log.error("No working shutdown command found")
                continue

            keycode = KEY_MAP.get(line)
            if keycode is None:
                log.debug("Unknown command: %r", line)
                continue

            ui.write(e.EV_KEY, keycode, 1)
            ui.syn()
            ui.write(e.EV_KEY, keycode, 0)
            ui.syn()
            log.info("Sent key for %s", line)
    finally:
        try:
            ser.close()
        except Exception:
            pass
        ui.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log.info("Shutting down")
        sys.exit(0)

// =====================================================================
//  Pi + Arduino Retro-TV Enclosure  -  v7 (FINAL)
//
//  For a BARE 14" laptop panel (N140BGE class, 1366x768) driven by an
//  LVDS controller board, with a Raspberry Pi and an Arduino Uno inside.
//
//  Controls on the front: joystick (navigation + press = ENTER),
//  potentiometer (volume), push button (hold 2s = shutdown).
//  There is no IR receiver in this design.
//
//  BUILD: one fused front/back/left/right frame with corner posts, plus a
//  separate top panel, bottom panel, and a cover that slides in directly
//  behind the screen panel and holds it against the opening.
//
//  What changed from v6:
//   - Added a rear cable opening. v6 was sealed shut, with no way to run
//     the Pi's power lead or the driver board's HDMI cable in.
//   - Added ventilation: slots in the top panel and high on both side
//     walls, so a Pi 4 running Kodi does not cook itself.
//   - No other geometry changed. v6 STLs and v7 STLs are interchangeable
//     except for those openings.
//
//  STILL TO DO once the LVDS driver board arrives: measure it and add its
//  standoffs plus rear cutouts for its HDMI / VGA / power connectors.
// =====================================================================
//  HOW TO USE
//  - Open in OpenSCAD (free, openscad.org)
//  - Set PART to render/export one piece at a time:
//      "assembly"   -> everything together, for viewing only
//      "side_frame" -> the fused front+back+left+right wall piece
//      "bottom"     -> bottom panel (carries the Pi + Arduino standoffs)
//      "top"        -> top panel (vented lid)
//      "backplate"  -> the slide-in cover that pins the screen panel
//  - File > Export > Export as STL exports whatever PART is showing
// =====================================================================

PART = "assembly";

// ---------------------- CORE DIMENSIONS ----------------------
box_w      = 384;   // box width  (X)
box_h      = 260;   // box HEIGHT (Z)
box_d      = 215;   // box depth  (Y)
t          = 3;     // wall thickness
corner_sq  = 15;    // square reinforcement post at each of the 4 corners

// ---------------------- SCREW HOLES ----------------------
pilot_d      = 2.6;   // pilot hole INTO corner posts, for self-tapping M3
panel_hole_d = 3.4;   // clearance hole THROUGH the top/bottom panels, for M3
hole_depth   = 7;     // how deep a pilot hole goes into a corner post

// ---------------------- STANDOFFS (Pi / Arduino) ----------------------
standoff_h   = 6;
standoff_od  = 6.5;
pi_pilot_d   = 2.0;    // self-tapping M2.5
uno_pilot_d  = 2.5;    // self-tapping M3

pi_hole_spacing_x = 58;    // Raspberry Pi 4B / 3B+ mounting rectangle
pi_hole_spacing_y = 49;
uno_holes = [               // Arduino Uno R3 standard 4-hole pattern
    [15.24,  2.54],
    [15.24, 50.80],
    [66.04, 17.78],
    [66.04, 45.72]
];
pi_origin  = [20, 120];   // toward the back, clear of the joystick module
uno_origin = [130, 120];

// ---------------------- SCREEN OPENING ----------------------
// Visible (active) area of the panel. Measure yours and change these two;
// the channel, cover and guides all follow from them.
screen_top_margin = 15;    // gap from the top edge of the frame
screen_w = 310;
screen_h = 174;
screen_x0 = (box_w - screen_w)/2;
screen_z0 = box_h - screen_top_margin - screen_h;

// ---------------------- PANEL + SLIDE-IN COVER ----------------------
// Panel and cover drop in from the top into ONE channel and slide down
// onto two ledges. Front to back the stack is:
//   front wall | panel | cover | retaining lips
// The cover sits directly against the back of the panel.
panel_outline_w    = 324;  // panel OUTER width  (typical 14" ~323.5) - MEASURE YOURS
panel_outline_h    = 206;  // panel OUTER height (typical 14" ~205.4) - MEASURE YOURS
panel_t            = 6;    // panel thickness                         - MEASURE YOURS
panel_bottom_extra = 20;   // opening bottom edge down to panel bottom edge - MEASURE YOURS
backplate_t = 3;           // cover thickness
fit_clr     = 0.4;         // sliding clearance
guide_t     = 2;           // side guide wall thickness
lip_t       = 2;           // rear retaining lip thickness
lip_w       = 10;          // how far each lip reaches over the cover edge
shelf_t     = 3;           // ledge thickness
ledge_w     = 40;          // ledge width (middle stays open for the panel's cable)

slot        = panel_t + backplate_t + 3*fit_clr;  // channel depth (Y)
panel_x0    = (box_w - panel_outline_w)/2;
shelf_z     = screen_z0 - panel_bottom_extra;     // panel rests here
backplate_w  = panel_outline_w;
backplate_h  = panel_outline_h - shelf_t - 10;    // stops 10mm below the panel top
backplate_x0 = panel_x0;
backplate_z0 = shelf_z + shelf_t;
backplate_y0 = t + panel_t + 2*fit_clr;           // directly behind the panel

// ---------------------- FRONT CONTROL CLUSTER ----------------------
//  - Joystick: 20mm hole + 4x M2 pilot holes on a 19.5mm square
//  - Potentiometer: 7mm hole for the bushing
//  - Button: 24mm panel hole (fits a 30mm-cap arcade button)
joystick_hole_d        = 20;
joystick_mount_spacing = 19.5;   // MEASURE your module and adjust
joystick_mount_pilot_d = 2.0;    // self-tapping M2
knob_hole_d   = 7;
button_hole_d = 24;
ctrl_pitch    = 40;              // center-to-center spacing
ctrl_center_x = box_w/2;
ctrl_center_z = 30;              // height above the floor
ctrl_positions = [
    [ctrl_center_x - ctrl_pitch, ctrl_center_z, joystick_hole_d],
    [ctrl_center_x,              ctrl_center_z, knob_hole_d],
    [ctrl_center_x + ctrl_pitch, ctrl_center_z, button_hole_d]
];
joystick_center = ctrl_positions[0];

// ---------------------- REAR CABLE OPENING ----------------------
// Pi power lead, driver-board HDMI and its power lead all pass through here.
cable_w  = 120;
cable_h  = 40;
cable_x0 = (box_w - cable_w)/2;   // clear of the corner posts
cable_z0 = 18;

// ---------------------- VENTILATION ----------------------
vent_w        = 4;      // slot width
vent_len      = 60;     // slot length
top_vent_x    = [49.5, 124.5, 199.5, 274.5];          // slot start positions (X)
top_vent_y    = [80, 92, 104, 116, 128, 140, 152, 164, 176];
side_vent_h   = 6;      // slot height (Z)
side_vent_len = 50;     // slot length (Y)
side_vent_y   = [30, 90, 148];
side_vent_z   = [205, 220, 235];

// =====================================================================
//  CORNERS  - posts = [signX, signY]  (-1 = near 0, +1 = near box_w/box_d)
// =====================================================================
corners = [[-1,-1], [1,-1], [-1,1], [1,1]];

function corner_x0(signX) = (signX < 0) ? 0 : box_w - corner_sq;
function corner_y0(signY) = (signY < 0) ? 0 : box_d - corner_sq;

// =====================================================================
//  ONE-PIECE SIDE FRAME (front + back + left + right, fused)
// =====================================================================
module side_frame() {
    color("lightgreen")
    union() {
        difference() {
            union() {
                // hollow perimeter tube
                difference() {
                    cube([box_w, box_d, box_h]);
                    translate([t, t, -1])
                        cube([box_w-2*t, box_d-2*t, box_h+2]);
                }
                // 4 solid corner posts, fused into the tube
                for (c = corners)
                    translate([corner_x0(c[0]), corner_y0(c[1]), 0])
                        cube([corner_sq, corner_sq, box_h]);
            }

            // top + bottom pilot holes at every corner post
            for (c = corners) {
                cx = corner_x0(c[0]) + corner_sq/2;
                cy = corner_y0(c[1]) + corner_sq/2;
                translate([cx, cy, box_h - hole_depth])
                    cylinder(d=pilot_d, h=hole_depth+0.5, $fn=16);
                translate([cx, cy, -0.5])
                    cylinder(d=pilot_d, h=hole_depth+0.5, $fn=16);
            }

            // control cluster, through the front wall
            for (c = ctrl_positions)
                translate([c[0], -0.5, c[1]])
                    rotate([-90,0,0])
                        cylinder(d=c[2], h=t+1, $fn=48);

            // joystick module mounting screws (4x, around the joystick hole)
            for (dx = [-1,1]) for (dz = [-1,1])
                translate([joystick_center[0] + dx*joystick_mount_spacing/2,
                           -0.5,
                           joystick_center[1] + dz*joystick_mount_spacing/2])
                    rotate([-90,0,0])
                        cylinder(d=joystick_mount_pilot_d, h=t+1, $fn=12);

            // screen opening, through the front wall
            translate([screen_x0, -0.5, screen_z0])
                cube([screen_w, t+1, screen_h]);

            // rear cable opening, through the back wall
            translate([cable_x0, box_d - t - 0.5, cable_z0])
                cube([cable_w, t+1, cable_h]);

            // side wall vents, high up on both walls, cut straight through
            for (sx = [-0.5, box_w - t - 0.5])
                for (vz = side_vent_z)
                    for (vy = side_vent_y)
                        translate([sx, vy, vz])
                            cube([t+1, side_vent_len, side_vent_h]);
        }

        // panel + cover channel, one assembly on each side. Each side has a
        // guide wall joined to the front wall, a lip at the back reaching
        // over the cover's edge, and a ledge for the panel to rest on.
        chan_z0 = shelf_z;
        chan_h  = box_h - chan_z0;
        for (side = [-1, 1]) {
            // guide wall, just outside the panel edge
            gx = (side < 0) ? panel_x0 - fit_clr - guide_t
                            : panel_x0 + panel_outline_w + fit_clr;
            translate([gx, t, chan_z0])
                cube([guide_t, slot + lip_t, chan_h]);
            // rear lip, reaching inward over the cover edge
            lx = (side < 0) ? gx : gx + guide_t - lip_w;
            translate([lx, t + slot, chan_z0])
                cube([lip_w, lip_t, chan_h]);
            // ledge the panel and cover rest on
            ex = (side < 0) ? gx + guide_t - 0.5
                            : panel_x0 + panel_outline_w + fit_clr - ledge_w + 0.5;
            translate([ex, t, chan_z0])
                cube([ledge_w, slot, shelf_t]);
        }
    }
}

// =====================================================================
//  TOP / BOTTOM PANELS
// =====================================================================
module top_panel() {
    color("plum")
    difference() {
        cube([box_w, box_d, t]);
        for (c = corners) {
            cx = corner_x0(c[0]) + corner_sq/2;
            cy = corner_y0(c[1]) + corner_sq/2;
            translate([cx, cy, -0.5])
                cylinder(d=panel_hole_d, h=t+1, $fn=16);
        }
        // ventilation slots over the electronics bay
        for (vx = top_vent_x)
            for (vy = top_vent_y)
                translate([vx, vy, -0.5])
                    cube([vent_len, vent_w, t+1]);
    }
}

module bottom_panel() {
    color("plum")
    union() {
        difference() {
            cube([box_w, box_d, t]);
            for (c = corners) {
                cx = corner_x0(c[0]) + corner_sq/2;
                cy = corner_y0(c[1]) + corner_sq/2;
                translate([cx, cy, -0.5])
                    cylinder(d=panel_hole_d, h=t+1, $fn=16);
            }
        }
        pi_standoffs();
        uno_standoffs();
    }
}

module pi_standoffs() {
    translate([pi_origin[0], pi_origin[1], t])
        for (p = [[0,0],[0,pi_hole_spacing_y],[pi_hole_spacing_x,0],[pi_hole_spacing_x,pi_hole_spacing_y]])
            translate([p[0], p[1], 0])
                difference() {
                    cylinder(d=standoff_od, h=standoff_h, $fn=24);
                    translate([0,0,-0.5]) cylinder(d=pi_pilot_d, h=standoff_h+1, $fn=16);
                }
}

module uno_standoffs() {
    translate([uno_origin[0], uno_origin[1], t])
        for (p = uno_holes)
            translate([p[0], p[1], 0])
                difference() {
                    cylinder(d=standoff_od, h=standoff_h, $fn=24);
                    translate([0,0,-0.5]) cylinder(d=uno_pilot_d, h=standoff_h+1, $fn=16);
                }
}

// ---------------------- SLIDE-IN COVER ----------------------
module backplate() {
    color("gray")
    cube([backplate_w, backplate_t, backplate_h]);
}

// =====================================================================
//  ASSEMBLY
// =====================================================================
EXPLODE = 0;

module assembly() {
    side_frame();
    translate([0, 0, -t-EXPLODE])     bottom_panel();
    translate([0, 0, box_h+EXPLODE])  top_panel();
    translate([backplate_x0, backplate_y0 + EXPLODE, backplate_z0])
        backplate();
    // ghost of the bare screen panel, for checking fit - NOT a printed part
    color("steelblue", 0.7)
    translate([panel_x0, t + fit_clr + EXPLODE/2, shelf_z + shelf_t])
        cube([panel_outline_w, panel_t, panel_outline_h - shelf_t]);
}

// =====================================================================
//  RENDER SELECTOR
// =====================================================================
if (PART == "side_frame") side_frame();
else if (PART == "bottom") bottom_panel();
else if (PART == "top") top_panel();
else if (PART == "backplate") backplate();
else assembly();
